package com.example.projectwireless;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class  Question1Activity extends AppCompatActivity {
    private EditText bwInput, quantizerBitInput, sourceEncoderRateInput, channelEncoderRateInput, interleaverBitInput;
    private Button calculateButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question1);


        bwInput = findViewById(R.id.bw_input);
        quantizerBitInput = findViewById(R.id.quantizer_bit_input);
        sourceEncoderRateInput = findViewById(R.id.source_encoder_rate_input);
        channelEncoderRateInput = findViewById(R.id.channel_encoder_rate_input);
        interleaverBitInput = findViewById(R.id.interleaver_bit_input);
        calculateButton = findViewById(R.id.calculate_button);

        // Set OnClickListener for the button
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateValues();
            }
        });
    }

    private void calculateValues() {
        // Get input values
        String bw = bwInput.getText().toString();
        String quantizerBit = quantizerBitInput.getText().toString();
        String sourceEncoderRate = sourceEncoderRateInput.getText().toString();
        String channelEncoderRate = channelEncoderRateInput.getText().toString();
        String interleaverBit = interleaverBitInput.getText().toString();

        // Perform your calculation logic here (if any)

        // Show the results in a dialog
        showDialog(bw, quantizerBit, sourceEncoderRate, channelEncoderRate, interleaverBit);
    }

    private void showDialog(String bw, String quantizerBit, String sourceEncoderRate, String channelEncoderRate, String interleaverBit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Calculation Results");

        String message = "- Sampling Frequency: " + (Integer.parseInt(bw)*2) +
                " K sample/sec\n\n- Quantization levels: " + Math.pow(2,Integer.parseInt(quantizerBit)) +
                "Levels\n\n- The Bit Rate at the Output of Source Encoder: " +Integer.parseInt(quantizerBit)*(Integer.parseInt(bw)*2) *Double.parseDouble(sourceEncoderRate) +
                "K bit/sec\n\n- Channel Encoder Rate: " + Integer.parseInt(quantizerBit)*(Integer.parseInt(bw)*2) *Double.parseDouble(sourceEncoderRate)*(1/Double.parseDouble(channelEncoderRate)) +
                "k bps\n\n -Interleaver Bit: " + Integer.parseInt(quantizerBit)*(Integer.parseInt(bw)*2) *Double.parseDouble(sourceEncoderRate)*(1/Double.parseDouble(channelEncoderRate));

        builder.setMessage(message);

        // Add an OK button to close the dialog
        builder.setPositiveButton("OK", null);

        // Show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}