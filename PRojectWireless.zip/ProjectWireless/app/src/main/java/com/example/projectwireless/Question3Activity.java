package com.example.projectwireless;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Question3Activity extends AppCompatActivity {
    private EditText pathLossInput, transmitGainInput, receiveGainInput,
            dataRateInput, antennaFeedLossInput, otherLossesInput, fadeMarginInput,
            receiverAmpGainInput, noiseFigureInput, noiseTemperatureInput, linkMarginInput;
    private Spinner pathLossInputSpinner, transmitGainInputSpinner, receiveGainInputSpinner,
            dataRateInputSpinner, antennaFeedLossInputSpinner, otherLossesInputSpinner, fadeMarginInputSpinner,
            receiverAmpGainInputSpinner, noiseFigureInputSpinner, noiseTemperatureInputSpinner, linkMarginInputSpinner,
            modulationTechniqueSpinner, biterrorrateSpinner;

    String[] modulation={"16-PSK","8-PSK","QBSK","BPSK"};
    String[] units={"dB","dBm","No Unit"};
    String[] BER_values={"1e-1","1e-2","1e-3","1e-4","1e-5"};
    String[] rate={"kbps","bps","mbps"};


    private Button calculateButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question3);

        // Initialize EditTexts
        pathLossInput = findViewById(R.id.path_loss_input);
        transmitGainInput = findViewById(R.id.transmit_gain_input);
        receiveGainInput = findViewById(R.id.receive_gain_input);
        dataRateInput = findViewById(R.id.data_rate_input);
        antennaFeedLossInput = findViewById(R.id.antenna_feed_loss_input);
        otherLossesInput = findViewById(R.id.other_losses_input);
        fadeMarginInput = findViewById(R.id.fade_margin_input);
        receiverAmpGainInput = findViewById(R.id.receiver_amp_gain_input);
        noiseFigureInput = findViewById(R.id.noise_figure_input);
        noiseTemperatureInput = findViewById(R.id.noise_temperature_input);
        linkMarginInput = findViewById(R.id.link_margin_input);


        // Initialize Spinners
        pathLossInputSpinner = findViewById(R.id.path_loss_input_spinner);
        transmitGainInputSpinner = findViewById(R.id.transmit_gain_input_spinner);
        receiveGainInputSpinner = findViewById(R.id.receive_gain_input_spinner);
        dataRateInputSpinner = findViewById(R.id.data_rate_input_spinner);
        antennaFeedLossInputSpinner = findViewById(R.id.antenna_feed_loss_input_spinner);
        otherLossesInputSpinner = findViewById(R.id.other_losses_input_spinner);
        fadeMarginInputSpinner = findViewById(R.id.fade_margin_input_spinner);
        receiverAmpGainInputSpinner = findViewById(R.id.receiver_amp_gain_input_spinner);
        noiseFigureInputSpinner = findViewById(R.id.noise_figure_input_spinner);
        noiseTemperatureInputSpinner = findViewById(R.id.noise_temperature_input_spinner);
        linkMarginInputSpinner = findViewById(R.id.link_margin_input_spinner);
        modulationTechniqueSpinner = findViewById(R.id.modulation_technique_spinner);
        biterrorrateSpinner = findViewById(R.id.biterrorrate);

        // Setup Spinners with data
        setupSpinner(pathLossInputSpinner, units);
        setupSpinner(transmitGainInputSpinner, units);
        setupSpinner(receiveGainInputSpinner, units);
        setupSpinner(dataRateInputSpinner, rate);
        setupSpinner(antennaFeedLossInputSpinner, units);
        setupSpinner(otherLossesInputSpinner, units);
        setupSpinner(fadeMarginInputSpinner, units);
        setupSpinner(receiverAmpGainInputSpinner, units);
        setupSpinner(noiseFigureInputSpinner, units);
        setupSpinner(noiseTemperatureInputSpinner, units);
        setupSpinner(linkMarginInputSpinner, units);
        setupSpinner(modulationTechniqueSpinner, modulation);
        setupSpinner(biterrorrateSpinner, BER_values);

        // Initialize Button
        calculateButton = findViewById(R.id.calculate_button);

        // Set OnClickListener for Calculate Button
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateTransmitPower();
            }
        });
    }
    private void calculateTransmitPower() {
        // Retrieve input values
        double Lp = Double.parseDouble(pathLossInput.getText().toString());
         double Gt = Double.parseDouble(transmitGainInput.getText().toString());
        double Gr = Double.parseDouble(receiveGainInput.getText().toString());
        double R = Double.parseDouble(dataRateInput.getText().toString());
        double Lf = Double.parseDouble(antennaFeedLossInput.getText().toString());
        double Lo = Double.parseDouble(otherLossesInput.getText().toString());
        double Mf = Double.parseDouble(fadeMarginInput.getText().toString());
        double Ga = Double.parseDouble(receiverAmpGainInput.getText().toString());
        double NF = Double.parseDouble(noiseFigureInput.getText().toString());
        double T = Double.parseDouble(noiseTemperatureInput.getText().toString());
        double Ml = Double.parseDouble(linkMarginInput.getText().toString());


        String pathLoss = getSelectedSpinnerItem(pathLossInputSpinner);
        String transmitGain = getSelectedSpinnerItem(transmitGainInputSpinner);
        String receiveGain = getSelectedSpinnerItem(receiveGainInputSpinner);
        String dataRate = getSelectedSpinnerItem(dataRateInputSpinner);
        String antennaFeedLoss = getSelectedSpinnerItem(antennaFeedLossInputSpinner);
        String otherLosses = getSelectedSpinnerItem(otherLossesInputSpinner);
        String fadeMargin = getSelectedSpinnerItem(fadeMarginInputSpinner);
        String receiverAmpGain = getSelectedSpinnerItem(receiverAmpGainInputSpinner);
        String noiseFigure = getSelectedSpinnerItem(noiseFigureInputSpinner);
        String noiseTemperature = getSelectedSpinnerItem(noiseTemperatureInputSpinner);
        String linkMargin = getSelectedSpinnerItem(linkMarginInputSpinner);
        String modulationTechnique = getSelectedSpinnerItem(modulationTechniqueSpinner);
        String biterrorrate = getSelectedSpinnerItem(biterrorrateSpinner);

        // Convert values to basic units where necessary
        Lp = convertToBasicUnit(Lp, pathLoss);
        Gt = convertToBasicUnit(Gt, transmitGain);
        Gr = convertToBasicUnit(Gr, receiveGain);
        Lf = convertToBasicUnit(Lf, antennaFeedLoss);
        Lo = convertToBasicUnit(Lo, otherLosses);
        Mf = convertToBasicUnit(Mf, fadeMargin);
        Ga = convertToBasicUnit(Ga, receiverAmpGain);
        NF = convertToBasicUnit(NF, noiseFigure);
        T = convertToBasicUnit(T, noiseTemperature);
        Ml = convertToBasicUnit(Ml, linkMargin);
        R  = convertToBasicUnit(R, dataRate);
        R=convertTodb(R);

        double BER = convertBitError(biterrorrate);
        // Constants and formulas
        double kB = 1.38e-23; // Boltzmann constant in Joules per Kelvin
        double Eb_No;
        try {
             Eb_No=getEbNo(modulationTechnique,BER);
            Log.d("HIIIIIIIIIIIIIIIIIII", "Eb/No for 8-PSK with BER : "+BER + Eb_No + " dB");

        } catch (IllegalArgumentException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        double Pt = Ml+Lp+Lf+Lo+Mf+convertTodb(kB)+T+NF+R-Gt-Gr-Ga+Eb_No;


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Result");
        String message = "Pt in db = "+Pt+" \n Pt in Watt = " +convertToWatt(Pt)+" Watt"+"\n Eb_No = "+Eb_No;
        builder.setMessage(message);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();

    }
    double convertToWatt(double pt){
        return Math.pow(10,pt/10);
    }

    double convertTodb(double valueinWatt){

        return 10*Math.log10(valueinWatt);
    }

    public static double getEbNo(String modulation, double ber) {
        switch (modulation.toUpperCase()) {
            case "BPSK":
            case "QPSK":
                return getEbNoForBpskQpsk(ber);
            case "8-PSK":
                return getEbNoFor8Psk(ber);
            case "16-PSK":
                return getEbNoFor16Psk(ber);
            default:
                throw new IllegalArgumentException("Invalid modulation technique.");
        }
    }
    private static double getEbNoForBpskQpsk(double ber) {
        if (ber == 1e-1) return 2;
        if (ber == 1e-2) return 4;
        if (ber == 1e-3) return 6.8;
        if (ber == 1e-4) return 8.5;
        if (ber == 1e-5) return 9.5;
        if (ber == 1e-6) return 10.5;
        throw new IllegalArgumentException("Invalid BER for BPSK/QPSK.");
    }

    private static double getEbNoFor8Psk(double ber) {
        if (ber == 1e-1) return 1.8;
        if (ber == 1e-2) return 7.1;
        if (ber == 1e-3) return 10;
        if (ber == 1e-4) return 11.5;
        if (ber == 1e-5) return 13;
        if (ber == 1e-6) return 14;
        throw new IllegalArgumentException("Invalid BER for 8-PSK.");
    }

    private static double getEbNoFor16Psk(double ber) {
        if (ber == 1e-1) return 5;
        if (ber == 1e-2) return 11;
        if (ber == 1e-3) return 14;
        if (ber == 1e-4) return 16;
        if (ber == 1e-5) return 17;
        if (ber == 1e-6) return 18.5;
        throw new IllegalArgumentException("Invalid BER for 16-PSK.");
    }
    private double convertBitError(String berString) {
        switch (berString) {
            case "1e-1":
                return 1e-1;
            case "1e-2":
                return 1e-2;
            case "1e-3":
                return 1e-3;
            case "1e-4":
                return 1e-4;
            case "1e-5":
                return 1e-5;
            default:
                throw new IllegalArgumentException("Invalid BER value: " + berString);
        }
    }

    private void setupSpinner(Spinner spinner, String[] units) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, units);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }
    private double convertToBasicUnit(double value, String unit) {
        switch (unit) {
            case "dBm":
                return value-30;
            case "No Unit":
                return convertTodb(value) ;
            case "kbps"    :
                return value*1000;
            case "mbps":
                return value*1000000;
            default:
                return value;
        }
    }
    // Method to retrieve selected item from each Spinner
    private String getSelectedSpinnerItem(Spinner spinner) {
        return spinner.getSelectedItem().toString();
    }
}
