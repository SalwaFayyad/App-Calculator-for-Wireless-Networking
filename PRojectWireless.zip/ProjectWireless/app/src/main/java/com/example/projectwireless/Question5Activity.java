package com.example.projectwireless;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Question5Activity extends AppCompatActivity {
    private EditText cityAreaInput, subscribersInput, avgCallsInput, avgDurationInput,carrier_channel,
            minSirInput, referencePowerInput, referenceDistanceInput, pathLossExponentInput, receiverSensitivityInput;

    private Spinner cityAreaSpinner, subscribersSpinner, avgCallsSpinner, avgDurationSpinner, dropProbabilitySpinner,
            minSirSpinner, referencePowerSpinner, referenceDistanceSpinner, receiverSensitivitySpinner;
    // Arrays for units
    String[] cityAreaUnits = {"Km²", "m²"};
    String[] avgDurationUnits = {"Hours","Minutes", "Seconds"};
    String[] minSirUnits = {"dB","Watt"};
    String[] referencePowerUnits = {"dB","Watt"};
    String[] referenceDistanceUnits = {"Meters", "Kilometers"};
    String[] receiverSensitivityUnits = {"Watts","dB"};
    String[] subscriberUnits = {"Thousands","Hundreds"};
    String[] avgCallsUnits = {"Day"};
    String[] dropProbabilityUnits = {"0.001","0.002","0.005","0.01","0.012","0.02","0.03","0.05"};
    // Erlang B table values for different GoS
    private static final double[][] erlangBTable = {
            {0.001, 0.002, 0.005, 0.010, 0.012, 0.013, 0.020, 0.022, 0.031, 0.053},
            {0.046, 0.065, 0.105, 0.136, 0.168, 0.176, 0.190, 0.223, 0.282, 0.381},
            {0.194, 0.249, 0.349, 0.455, 0.489, 0.505, 0.530, 0.602, 0.715, 0.899},
            {0.439, 0.535, 0.701, 0.869, 0.922, 0.946, 0.994, 1.092, 1.296, 1.525},
            {0.762, 0.900, 1.132, 1.361, 1.431, 1.464, 1.520, 1.657, 1.875, 2.218},
            {1.100, 1.300, 1.600, 1.900, 2.000, 2.100, 2.300, 2.500, 3.000},
            {1.600, 1.900, 2.300, 2.700, 2.900, 3.100, 3.400, 3.800, 4.500},
            {2.100, 2.300, 2.700, 3.100, 3.400, 3.600, 4.100, 4.500, 5.400},
            {2.600, 2.900, 3.400, 3.800, 4.100, 4.500, 5.000, 5.400, 6.500},
            {3.100, 3.400, 4.000, 4.500, 4.700, 5.000, 5.600, 6.100, 7.400},
            {3.700, 4.000, 4.600, 5.200, 5.300, 5.500, 5.800, 6.400, 6.900, 8.300},
            {4.200, 4.600, 5.300, 5.900, 6.100, 6.100, 6.600, 7.100, 7.800, 9.400},
            {4.800, 5.300, 6.100, 6.700, 6.900, 7.100, 7.500, 8.200, 8.900, 10.600},
            {5.400, 5.900, 6.700, 7.400, 7.600, 7.800, 8.300, 9.000, 9.700, 11.500},
            {6.000, 6.500, 7.400, 8.100, 8.400, 8.600, 9.100, 9.800, 10.500, 12.500},
            {6.700, 7.300, 8.100, 8.900, 9.100, 9.300, 9.900, 10.700, 11.500, 13.600},
            {7.400, 8.100, 8.900, 9.700, 10.000, 10.200, 10.800, 11.700, 12.600, 14.700},
            {8.100, 8.800, 9.600, 10.500, 10.800, 11.000, 11.700, 12.600, 13.600, 15.800},
            {8.700, 9.600, 10.400, 11.300, 11.700, 11.900, 12.600, 13.600, 14.700, 16.900},
            {9.400, 10.100, 11.100, 12.000, 12.300, 12.500, 13.200, 14.200, 15.300, 18.000}
    };



    private Button calculateButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question5);

        // Initialize EditTexts
        cityAreaInput = findViewById(R.id.city_area_input);
        carrier_channel= findViewById(R.id.carrierchannels_id);
        subscribersInput = findViewById(R.id.subscribers_input);
        avgCallsInput = findViewById(R.id.avg_calls_input);
        avgDurationInput = findViewById(R.id.avg_duration_input);
        minSirInput = findViewById(R.id.min_sir_input);
        referencePowerInput = findViewById(R.id.reference_power_input);
        referenceDistanceInput = findViewById(R.id.reference_distance_input);
        pathLossExponentInput = findViewById(R.id.path_loss_exponent_input);
        receiverSensitivityInput = findViewById(R.id.receiver_sensitivity_input);

        // Initialize Spinners
        cityAreaSpinner = findViewById(R.id.city_area_spinner);
        subscribersSpinner = findViewById(R.id.subscribers_spinner);
        avgCallsSpinner = findViewById(R.id.avg_calls_spinner);
        avgDurationSpinner = findViewById(R.id.avg_duration_spinner);
        dropProbabilitySpinner = findViewById(R.id.drop_probability_spinner);
        minSirSpinner = findViewById(R.id.min_sir_spinner);
        referencePowerSpinner = findViewById(R.id.reference_power_spinner);
        referenceDistanceSpinner = findViewById(R.id.reference_distance_spinner);
        receiverSensitivitySpinner = findViewById(R.id.receiver_sensitivity_spinner);

        // Initialize Button
        calculateButton = findViewById(R.id.calculate_button);


        // Set up adapters for spinners
        setupSpinner(cityAreaSpinner, cityAreaUnits);
        setupSpinner(subscribersSpinner, subscriberUnits);
        setupSpinner(avgCallsSpinner, avgCallsUnits);
        setupSpinner(avgDurationSpinner, avgDurationUnits);
        setupSpinner(dropProbabilitySpinner, dropProbabilityUnits);
        setupSpinner(minSirSpinner, minSirUnits);
        setupSpinner(referencePowerSpinner, referencePowerUnits);
        setupSpinner(referenceDistanceSpinner, referenceDistanceUnits);
//        setupSpinner(pathLossExponentSpinner, pathLossExponentUnits);
        setupSpinner(receiverSensitivitySpinner, receiverSensitivityUnits);


        // Set onClickListener for Calculate button
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate();
            }
        });

    }
    // Method to set up a spinner with an array of units
    private void setupSpinner(Spinner spinner, String[] units) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, units);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    // Method to perform calculation based on inputs and spinner selections
    private void calculate() {
        try {
            // Retrieve values from EditTexts
            double cityArea = Double.parseDouble(cityAreaInput.getText().toString());
            int carriers =Integer.parseInt(carrier_channel.getText().toString());
            int subscribers = Integer.parseInt(subscribersInput.getText().toString());
            double avgCalls = Double.parseDouble(avgCallsInput.getText().toString());
            double avgDuration = Double.parseDouble(avgDurationInput.getText().toString());
            double minSir = Double.parseDouble(minSirInput.getText().toString());
            double referencePower = Double.parseDouble(referencePowerInput.getText().toString());
            double referenceDistance = Double.parseDouble(referenceDistanceInput.getText().toString());
            double pathLossExponent = Double.parseDouble(pathLossExponentInput.getText().toString());
            double receiverSensitivity = Double.parseDouble(receiverSensitivityInput.getText().toString());

            // Retrieve selected units from Spinners
            String cityAreaUnit = cityAreaSpinner.getSelectedItem().toString();
            String subscriberUnit = subscribersSpinner.getSelectedItem().toString();
            String avgCallsUnit = avgCallsSpinner.getSelectedItem().toString();
            String avgDurationUnit = avgDurationSpinner.getSelectedItem().toString();
            String dropProbabilityUnit = dropProbabilitySpinner.getSelectedItem().toString();
            String minSirUnit = minSirSpinner.getSelectedItem().toString();
            String referencePowerUnit = referencePowerSpinner.getSelectedItem().toString();
            String referenceDistanceUnit = referenceDistanceSpinner.getSelectedItem().toString();
            String receiverSensitivityUnit = receiverSensitivitySpinner.getSelectedItem().toString();

            if (cityAreaUnit.equals("Km²")){
                cityArea=1000000*cityArea;
            }
            if (cityAreaUnit.equals("m²")){
                cityArea=1000*cityArea;
            }
            if (subscriberUnit.equals("Thousands")){
                subscribers=subscribers*1000;
            }
            if (subscriberUnit.equals("Hundreds")){
                subscribers=subscribers*100;
            }


            // Adjust minSir, referencePower, referenceDistance, receiverSensitivity based on units
            if (minSirUnit.equals("dB")) {
                minSir = convertFromdBToWatt(minSir); // Convert minSir from dB to Watt
            }

            if (referencePowerUnit.equals("dB")) {
                referencePower = convertFromdBToWatt(referencePower); // Convert referencePower from dB to Watt
            }

            if (referenceDistanceUnit.equals("Kilometers")) {
                referenceDistance = referenceDistance * 1000; // Convert from Kilometers to Meters
            }

            if (receiverSensitivityUnit.equals("dB")) {
                receiverSensitivity = convertFromdBToWatt(receiverSensitivity); // Convert receiverSensitivity from Watt to dB
            }

            if (avgCallsUnit.equals("Day")){
                avgCalls=avgCalls/(24*60);
            }

            if (avgDurationUnit.equals("Hours")){
                avgDuration=avgDuration*60;
            }
            if (avgDurationUnit.equals("Seconds")){
                avgDuration=avgDuration/60;
            }


            double maxdistance = referenceDistance / Math.pow((receiverSensitivity / referencePower), (1.0 / pathLossExponent));
            double cellsize = (3.0 / 2.0) * Math.sqrt(3) * Math.pow(maxdistance, 2);
            double number_cells= cityArea/cellsize;
            // Round up to the nearest whole number
            number_cells = Math.ceil(number_cells);
            int numberOfCells = (int) number_cells;

            double lambda_H =avgCalls * avgDuration ; // lambda*H
            double traffic_load=1.0*subscribers*lambda_H;
            double traffic_load_cell = traffic_load/(numberOfCells*1.0);

            double clusters_num_cell = (1.0/3.0)*Math.pow(6*minSir,2.0/3.0);

            // Start with large values for i and j
            int minI = 0, minJ = 0;
            double minValue = Double.MAX_VALUE;

            // Iterate over possible values of i and j
            for (int i = 0; i <= 100; i++) {
                for (int j = 0; j <= 100; j++) {
                    double result = i * i + i * j + j * j;
                    if (result > clusters_num_cell && result < minValue) {
                        minValue = result;
                        minI = i;
                        minJ = j;
                    }
                }
            }



            String formattedMaxDistance = String.format("%.3f", maxdistance);
            String formattedCellSize = String.format("%.1f", cellsize);
            String formattedtraffic_load = String.format("%.3f", traffic_load);
            String formattedload_cell = String.format("%.2f", traffic_load_cell);

            // for g
            int channels = findChannels(traffic_load_cell, Double.parseDouble(dropProbabilityUnit));
            double carrierfound = Math.ceil(1.0*channels / carriers);
            int carrierfoundd = (int) carrierfound;

            // for h
            int channels2 = findChannels(traffic_load_cell,0.05);
            double carrierfound2 = Math.ceil(1.0*channels2 / carriers);
            int carrierfoundd2 = (int) carrierfound2;

            String message = "- Maximum distance between transmitter and receiver for reliable communication = "+formattedMaxDistance+
                             "\n\n- Maximum cell size assuming hexagonal cells (A_Cell)= "+ formattedCellSize+
                             "\n\n- The number of cells in the service area = "+numberOfCells+
                             "\n\n- Traffic load in the whole cellular system in Erlangs [A= U*Au ] = "+formattedtraffic_load+
                             "\n\n- Traffic load in each cell in Erlangs "+formattedload_cell+
                             "\n\n- Number of cells in each cluster = "+ minValue+
                             "\n\n- Minimum number of carriers needed (in the whole system) to achieve the required Quality of Service = "+carrierfoundd+" for number of channels = "+channels+
                             "\n\n- Minimum number of carriers needed (in the whole system) to achieve the required \n" +
                    "Quality of Service if QoS has changed to 0.05.= " +carrierfoundd2+" for number of channels = "+channels2;


            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Result");
            builder.setMessage(message);
            builder.setPositiveButton("OK", null);
            AlertDialog dialog = builder.create();
            dialog.show();
        } catch (NumberFormatException e) {
            // Handle if any of the inputs are not valid numbers
            Toast.makeText(getApplicationContext(), "Please enter valid numbers in all fields", Toast.LENGTH_SHORT).show();
        }
    }
    private double convertFromdBToWatt(double dBValue) {
        return Math.pow(10, dBValue / 10);
    }

    private double convertFromWattTodB(double wattValue) {
        return 10 * Math.log10(wattValue);
    }
    public static int findChannels(double erlangs, double gos) {
        int gosIndex;
        if (gos == 0.001) {
            gosIndex = 0;
        } else if (gos == 0.002) {
            gosIndex = 1;
        } else if (gos == 0.005) {
            gosIndex = 2;
        } else if (gos == 0.01) {
            gosIndex = 3;
        } else if (gos == 0.012) {
            gosIndex = 4;
        } else if (gos == 0.02) {
            gosIndex = 5;
        } else if (gos == 0.03) {
            gosIndex = 6;
        } else if (gos == 0.05) {
            gosIndex = 7;
        } else {
            throw new IllegalArgumentException("Unsupported GoS value");
        }

        int closestChannels = 1;
        double minDifference = Math.abs(erlangBTable[0][gosIndex] - erlangs);

        for (int channels = 1; channels < erlangBTable.length; channels++) {
            double difference = Math.abs(erlangBTable[channels][gosIndex] - erlangs);
            if (difference < minDifference) {
                minDifference = difference;
                closestChannels = channels + 1;
            }
        }

        return closestChannels;
    }


}