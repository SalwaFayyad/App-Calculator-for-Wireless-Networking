package com.example.projectwireless;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class Question2Activity extends AppCompatActivity {
    private EditText bwInput, subcarrierSpacingInput, numberOfOfdmInput, durationInput, parallelResourceBlock;
    private Spinner bwUnitSpinner, durationUnitSpinner, subcarrierSpacingUnitSpinner, modulationTechniqueInput;
    private Button calculateButton;
    String[] modulation = {"16-PSK", "16-QAM", "8-PSK", "1024-QAM", "4-PSK", "4-QAM", "BFSK", "BPSK"};
    String[] bwUnits = {"Hz", "KHz", "MHz"};
    String[] durationUnits = {"ms", "s"};
    String[] subcarrierUnits = {"Hz", "KHz", "MHz"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question2);

        // Initialize EditTexts
        bwInput = findViewById(R.id.bw_input1);
        subcarrierSpacingInput = findViewById(R.id.subcarrier_spacing_input);
        numberOfOfdmInput = findViewById(R.id.number_of_ofdm_input);
        durationInput = findViewById(R.id.duration_input);
        parallelResourceBlock = findViewById(R.id.parallel_resource_block);

        // Initialize Spinners
        bwUnitSpinner = findViewById(R.id.spinner2);
        subcarrierSpacingUnitSpinner = findViewById(R.id.spinner4);
        durationUnitSpinner = findViewById(R.id.spinner3);
        modulationTechniqueInput = findViewById(R.id.modulation_technique_input);

        // Initialize Button
        calculateButton = findViewById(R.id.calculate_button);

        // Set up spinners
        ArrayAdapter<String> modulationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, modulation);
        modulationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        modulationTechniqueInput.setAdapter(modulationAdapter);

        ArrayAdapter<String> bwUnitAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, bwUnits);
        bwUnitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        bwUnitSpinner.setAdapter(bwUnitAdapter);

        ArrayAdapter<String> subcarrierUnitAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, subcarrierUnits);
        subcarrierUnitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subcarrierSpacingUnitSpinner.setAdapter(subcarrierUnitAdapter);

        ArrayAdapter<String> durationUnitAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, durationUnits);
        durationUnitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        durationUnitSpinner.setAdapter(durationUnitAdapter);

        // Set OnClickListener for the calculate button
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateValues();
            }
        });
    }

    private void calculateValues() {
        String bw = bwInput.getText().toString();
        String bwUnit = bwUnitSpinner.getSelectedItem().toString();
        String subcarrierSpacing = subcarrierSpacingInput.getText().toString();
        String subcarrierUnit = subcarrierSpacingUnitSpinner.getSelectedItem().toString();
        String numberOfOfdm = numberOfOfdmInput.getText().toString();
        String duration = durationInput.getText().toString();
        String durationUnit = durationUnitSpinner.getSelectedItem().toString();
        String modulationTechnique = modulationTechniqueInput.getSelectedItem().toString();
        String parallelBlock = parallelResourceBlock.getText().toString();

        // Convert bandwidth, subcarrier spacing, and duration to standard units
        double bwValue = convertToStandardUnit(Double.parseDouble(bw), bwUnit);
        double subcarrierSpacingValue = convertToStandardUnit(Double.parseDouble(subcarrierSpacing), subcarrierUnit);
        double durationValue = convertToStandardUnit(Double.parseDouble(duration), durationUnit);

        showDialog(bwValue, subcarrierSpacingValue, numberOfOfdm, durationValue, modulationTechnique, parallelBlock);
    }

    private double convertToStandardUnit(double value, String unit) {
        switch (unit) {
            case "KHz":
                return value * 1000;
            case "MHz":
                return value * 1000000;
            case "ms":
                return value * 1e-3;
            default:
                return value; // already in standard unit (Hz or s)
        }
    }

    private void showDialog(double bw, double subcarrierSpacing, String numberOfOfdm, double duration, String modulationTechnique, String parallelBlock) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Result");

        // Calculate log base 2 of modulationTechnique
        int numberOfBitsPerResourceElement = getBitsPerSymbol(modulationTechnique);

        // Calculate the number of subcarriers
        int subcarriers = 0;
        try {
            if (bw % subcarrierSpacing != 0) {
                throw new ArithmeticException("Division is not exact");
            }
            subcarriers = (int) (bw / subcarrierSpacing);
            // Clear any previous errors
            subcarrierSpacingInput.setError(null);
            bwInput.setError(null);
        } catch (ArithmeticException e) {
            subcarrierSpacingInput.setError("Please enter valid division numbers");
            bwInput.setError("Please enter valid division numbers");
            return; // Exit the method if there's an error
        }

        int numberOfBitsPerOFDMsymbols = subcarriers * numberOfBitsPerResourceElement;
        int numberOfBitsPerOFDMBlock = numberOfBitsPerOFDMsymbols * Integer.parseInt(numberOfOfdm);

        double maximumTransmissionRate = (Integer.parseInt(parallelBlock) * numberOfBitsPerOFDMBlock) / duration;
        // You can now use these values as needed, for example:
        String message = "- Number of Bits per Resource element = " + numberOfBitsPerResourceElement + " bits" +
                "\n\n- Number of Bits per OFDM Symbols = " + numberOfBitsPerOFDMsymbols + " bits" +
                "\n\n- Number of Bits per OFDM Resource Block = " + numberOfBitsPerOFDMBlock + " bits" +
                "\n\n- Maximum Transmission Rate for " + Integer.parseInt(parallelBlock) + " = " + maximumTransmissionRate + " bps";
        builder.setMessage(message);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Utility method to get the number of bits per symbol for a given modulation technique
    private int getBitsPerSymbol(String modulation) {
        switch (modulation) {
            case "16-PSK":
                return 4;
            case "16-QAM":
                return 4;
            case "8-PSK":
                return 3;
            case "1024-QAM":
                return 10;
            case "4-PSK":
                return 2;
            case "4-QAM":
                return 2;
            case "BFSK":
                return 1;
            case "BPSK":
                return 1;
            default:
                return 0;
        }
    }
}