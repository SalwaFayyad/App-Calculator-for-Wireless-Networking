package com.example.projectwireless;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Question4Activity extends AppCompatActivity {

    private EditText bwInput;
    private Spinner bwSpinner;
    private EditText propagationTimeInput;
    private Spinner propagationTimeSpinner;
    private EditText frameSizeInput;
    private Spinner frameSizeSpinner;
    private EditText frameRateInput;
    private Spinner frameRateSpinner;
    private Spinner systemSpinner;
    private Button calculateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question4);

        // Initialize UI components
        bwInput = findViewById(R.id.bw_input);
        bwSpinner = findViewById(R.id.bw_spinner);
        propagationTimeInput = findViewById(R.id.propagation_time_input);
        propagationTimeSpinner = findViewById(R.id.propagation_time_spinner);
        frameSizeInput = findViewById(R.id.frame_size_input);
        frameSizeSpinner = findViewById(R.id.frame_size_spinner);
        frameRateInput = findViewById(R.id.frame_rate_input);
        frameRateSpinner = findViewById(R.id.frame_rate_spinner);
        systemSpinner = findViewById(R.id.system_spinner);
        calculateButton = findViewById(R.id.calculate_button);

        // Populate the spinners with unit options
        setUpSpinner(bwSpinner, new String[]{"bps", "Kbps", "Mbps"});
        setUpSpinner(propagationTimeSpinner, new String[]{"s", "ms", "µs"});
        setUpSpinner(frameSizeSpinner, new String[]{"bits", "Kb"});
        setUpSpinner(frameRateSpinner, new String[]{"frames/s", "frames/ms","Kframes/s"});

        // Populate the MAC system spinner with system options
        String[] systems = {
                "Pure Aloha",
                "Slotted Aloha",
                "Unslotted Non-Persistent CSMA",
                "Slotted Persistent CSMA",
                "Unslotted 1-Persistent CSMA",
                "Slotted 1-Persistent CSMA"
        };
        ArrayAdapter<String> systemAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, systems);
        systemAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        systemSpinner.setAdapter(systemAdapter);

        // Set onClickListener for the calculate button
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String bwStr = bwInput.getText().toString();
                String propagationTimeStr = propagationTimeInput.getText().toString();
                String frameSizeStr = frameSizeInput.getText().toString();
                String frameRateStr = frameRateInput.getText().toString();
                String selectedSystem = systemSpinner.getSelectedItem().toString();

                if (!bwStr.isEmpty() && !propagationTimeStr.isEmpty() && !frameSizeStr.isEmpty() && !frameRateStr.isEmpty()) {
                    double bw = convertToBasicUnit(Double.parseDouble(bwStr), bwSpinner.getSelectedItem().toString());
                    double propagationTime = convertToBasicUnit(Double.parseDouble(propagationTimeStr), propagationTimeSpinner.getSelectedItem().toString());
                    double frameSize = convertToBasicUnit(Double.parseDouble(frameSizeStr), frameSizeSpinner.getSelectedItem().toString());
                    double frameRate = convertToBasicUnit(Double.parseDouble(frameRateStr), frameRateSpinner.getSelectedItem().toString());

                    double throughput = calculateThroughput(bw, propagationTime, frameSize, frameRate, selectedSystem);
                    showThroughputDialog(throughput);
                } else {
                    Toast.makeText(Question4Activity.this, "Please enter valid values.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setUpSpinner(Spinner spinner, String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    private double convertToBasicUnit(double value, String unit) {
        switch (unit) {
            case "bps":
                return value;
            case "Kbps":
                return value * 1000;
            case "Mbps":
                return value * 1000000;
            case "s":
                return value;
            case "ms":
                return value / 1000;
            case "µs":
                return value / 1000000;
            case "bits":
                return value;
            case "Kb":
                return value * 1000;
            case "frames/s":
                return value;
            case "frames/ms":
                return value * 1000;
            case "Kframes/s":
                return value * 1000;
            default:
                return value;
        }
    }

    private double calculateThroughput(double bw, double propagationTime, double frameSize, double frameRate, String system) {
        double frameTransmissionTime = frameSize / bw;
        double alpha = propagationTime / frameTransmissionTime;
        double G = frameRate * frameTransmissionTime; // Offered load

        switch (system) {
            case "Pure Aloha":
                return G * Math.exp(-2 * G) * 100;
            case "Slotted Aloha":
                return G * Math.exp(-G) * 100;
            case "Unslotted Non-Persistent CSMA":
                return (G * Math.exp(-2 * alpha * frameTransmissionTime)) / (G * (1 + 2 * alpha) + Math.exp(-G * alpha)) * 100;
            case "Slotted Non-Persistent CSMA":
                return (alpha * G * Math.exp(-2 * alpha * frameTransmissionTime)) / (1 - Math.exp(-G * alpha) + alpha) * 100;
            case "Unslotted 1-Persistent CSMA":
                return ((G * (1 + G + alpha * G * (1 + G + (alpha * G) / 2))) * Math.exp(-G * (1 + 2 * alpha))) /
                        ((G * (1 + 2 * alpha)) * (1 - Math.exp(-G * alpha)) + (1 + alpha * G) * Math.exp(-G * (1 + alpha))) * 100;
            case "Slotted 1-Persistent CSMA":
                return (G * (1 + alpha - Math.exp(-alpha * G)) * Math.exp(-G * (1 + alpha))) /
                        ((1 + alpha) * (1 - Math.exp(-alpha * G)) + alpha * Math.exp(-G * (1 + alpha))) * 100;
            default:
                return 0.0;
        }
    }

    private void showThroughputDialog(double throughput) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Throughput Result");
        builder.setMessage("Throughput: " + throughput + "%");
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}